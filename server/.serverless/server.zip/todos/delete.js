'use strict';


const uuid = require('uuid');
const AWS = require('aws-sdk');

const TODO_TABLE = process.env.TODO_TABLE;
const IS_OFFLINE = process.env.IS_OFFLINE;
let dynamodb;
if (IS_OFFLINE) {
    dynamodb = new AWS.DynamoDB.DocumentClient({
        region: 'localhost',
        endpoint: 'http://localhost:8000'
    });
    console.log(dynamodb);
}
else {
    dynamodb = new AWS.DynamoDB.DocumentClient();
}

module.exports.delete = (event, context, callback) => {

    const params = {
        TableName: TODO_TABLE,
        Key: {
            id: event.pathParameters.id
        }
    };


    dynamodb.delete(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t remove the todo item.'));
            return;
        }

        const response = {
            statusCode: 200,
            body: JSON.stringify({})
        };
        callback(null, response);
    })

};