'use strict';


const uuid = require('uuid');
const AWS = require('aws-sdk');

const TODO_TABLE = process.env.TODO_TABLE;
const IS_OFFLINE = process.env.IS_OFFLINE;
let dynamodb;
if (IS_OFFLINE) {
    dynamodb = new AWS.DynamoDB.DocumentClient({
        region: 'localhost',
        endpoint: 'http://localhost:8000'
    });
    console.log(dynamodb);
}
else {
    dynamodb = new AWS.DynamoDB.DocumentClient();
}

module.exports.create = (event, context, callback) => {

    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);

    if (typeof data.text !== 'string') {
      console.error('Validation Failed!');
      callback(new Error('Couldn\'t create the todo item.'));
      return;
    }

    const params = {
      TableName: TODO_TABLE,
      Item: {
          id: uuid.v1(),
          text: data.text,
          checked: false,
          updatedAt: timestamp,
          createdAt: timestamp
      }
    };

    dynamodb.put(params, (error, result) => {

        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the todo item.'));
            return;
        }

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        };
        callback(null, response);
    })

};
