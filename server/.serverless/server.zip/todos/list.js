'use strict';


const uuid = require('uuid');
const AWS = require('aws-sdk');

const TODO_TABLE = process.env.TODO_TABLE;
const IS_OFFLINE = process.env.IS_OFFLINE;
let dynamodb;
if (IS_OFFLINE) {
   dynamodb = new AWS.DynamoDB.DocumentClient({
      region: 'localhost',
      endpoint: 'http://localhost:8000'
   });
   console.log(dynamodb);
}
else {
   dynamodb = new AWS.DynamoDB.DocumentClient();
}

const params = {
  TableName: TODO_TABLE
};

module.exports.list = (event, context, callback) => {

   dynamodb.scan(params, (error, result) => {
      if (error) {
         console.error(error);
         callback(new Error('Couldn\'t fetch the todo'));
         return;
      }

      const response = {
         statusCode: 200,
         headers: {
            'Access-Control-Allow-Origin': '*',
         },
         body: JSON.stringify(result.Items)
      };
      callback(null, response);
   })

};
