'use strict';


const uuid = require('uuid');
const AWS = require('aws-sdk');

const TODO_TABLE = process.env.TODO_TABLE;
const IS_OFFLINE = process.env.IS_OFFLINE;
let dynamodb;
if (IS_OFFLINE) {
    dynamodb = new AWS.DynamoDB.DocumentClient({
        region: 'localhost',
        endpoint: 'http://localhost:8000'
    });
    console.log(dynamodb);
}
else {
    dynamodb = new AWS.DynamoDB.DocumentClient();
}

module.exports.update = (event, context, callback) => {

    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);

    const params = {
        TableName: TODO_TABLE,
        Item: {
            id: event.pathParameters.id,
            text: data.text,
            checked: data.checked,
            updatedAt: timestamp,
        }
    };

    if (typeof data.text !== 'string' || typeof data.checked !== 'boolean') {
        console.error('Validation Failed!');
        callback(new Error('Couldn\'t update the todo item.'));
        return;
    }

    dynamodb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the todo item.'));
            return;
        }

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        };
        callback(null, response);
    })

};
